#ifndef Ds1307_H
#define Ds1307_H

#define SLAVE_READ		0xD1  //unique id 1101 0001 8th bit for read
#define SLAVE_WRITE		0xD0   //unique id 1101 0000 8th bit for write 


//#define SEC_ADDR		0x00
//#define MIN_ADDR		0x01
//#define HOUR_ADDR		0x02
#define DAY_ADDR		0x03
#define DATE_ADDR		0x04
#define MONTH_ADDR		0x05
#define YEAR_ADDR		0x06
#define CNTL_ADDR		0x07

void init_ds1307(void);
void write_ds1307(unsigned char address1,  unsigned char data);    //write function by using address and data
unsigned char read_ds1307(unsigned char address1);   //read function by using address

#endif